[ссылка на сайт](http://t99662dp.beget.tech/)
[ссылка на игру](https://durashca.github.io/wseznai/version4/)